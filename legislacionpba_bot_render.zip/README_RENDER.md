# legislacionpba_bot para Render
Despliegue rápido:

1. Crear nuevo Web Service en Render
2. Subir este ZIP o conectar desde GitHub
3. Start Command: python bot.py
4. Variable de entorno: TELEGRAM_BOT_TOKEN = tu token
